switch = 1
set{260,0,'rotationz'}
for b = 260, 271 do 
    ease{b,1,bounce,120,'zoom',-200,'tiny',30*switch,'rotationy',-10,'flip',100*switch,'tipsy',30*switch,'rotationz',}
  ease{b,1,outQuad,50+50*-switch,'reverse0',50+50*-switch,'reverse1',50+50*switch,'reverse2',50+50*switch,'reverse3'}
    switch = switch * -1
end
for b = 273, 288 do 
    ease{b,1,bounce,120,'zoom',-200,'tiny',30*switch,'rotationy',-10,'flip',100*switch,'tipsy',30*switch,'rotationz',}
  ease{b,1,outQuad,50+50*-switch,'reverse0',50+50*-switch,'reverse1',50+50*switch,'reverse2',50+50*switch,'reverse3'}
    switch = switch * -1
end


ease{272,1,outQuad,0,'reverse'}
ease{272,1,bounce,150,'zoom',0,'reverse0',0,'reverse1',0,'reverse2',0,'reverse3',200,'tipsy',-20,'flip',-200,'tiny'}

ease{277.75,0.25,outQuad,0,'reverse0',0,'reverse1'}
ease{278,0.25,outQuad,0,'reverse2',0,'reverse3'}

ease{285.75,0.25,outQuad,100,'reverse0',100,'reverse1'}
ease{286,0.25,outQuad,100,'reverse2',100,'reverse3'}
ease{288,1,outQuad,0,'reverse0',0,'reverse1',0,'reverse2',0,'reverse3'}

ease{289,1,bounce,-100,'tiny',120,'zoom',30,'rotationy',30,'rotationz'}
ease{289,0.5,outQuad,100,'reverse0',100,'reverse2'}
ease{289.5,1,bounce,-100,'tiny',120,'zoom',-30,'rotationy',-30,'rotationz'}
ease{289.5,0.5,outQuad,0,'reverse0',0,'reverse2',100,'reverse1',100,'reverse3'}
ease{290,2,bounce,-100,'tiny',120,'zoom',30,'rotationy',30,'rotationz',100,'reverse0',100,'reverse2'}
ease{290,1,outQuad,0,'reverse0',0,'reverse2',0,'reverse1',0,'reverse3'}

switch = -1
for b = 292, 319 do 
    ease{b,1,bounce,120,'zoom',-100,'tiny'}
    ease{b,1,bounce,-200*switch,'parabolax',20*switch,'rotationz',40*switch,'rotationy',200*switch,'movex',20*switch,'rotationx',50*switch,'drunk'}
   -- ease{b,1,bounce,200*switch,'parabolax',-20*switch,'rotationz',-40*switch,'rotationy',-200*switch,'movex',20*switch,'rotationx',-50*switch,'drunk',plr=2}
    ease{b,1,outQuad,50+50*switch,'reverse0',50+50*-switch,'reverse1',50+50*switch,'reverse2',50+50*-switch,'reverse3'}
   switch = switch * -1
end
ease{319,1,outQuad,0,'reverse0',0,'reverse1',0,'reverse2',0,'reverse3'}
