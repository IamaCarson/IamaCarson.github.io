
switch = 1
perframe{32,64,function(b,p)
    bgColor:diffuse(sin(b)/2+0.5,cos(b)/2+0.5,tan(b)/2+0.5,1)
    my_sprite2:rotationx(sin(b/2)*30)
    my_sprite2:rotationz(2)
    my_sprite2:rotationy(cos(b/2)*30)
end}
for b = 32, 64, 1 do
    ease{b,1,bounce,0.9,'bgaftz',1,'bgafta',10*switch,'bgaftrz',-200,'tiny'}
    add{b,1,bounce,-20,'flip'}
    add{b,1,bounce,30*switch,'rotationy',-10*switch,'rotationz',100*switch,'drunk',plr=1}
    ease{b,1,outQuad,(100/2)+(100/2)*switch,'invert',}
    add{b,1,bounce,-30*switch,'rotationy',10*switch,'rotationz',-100*switch,'drunk',plr=2}
    ease{b,1,bounce,50+50*-switch,'tiny2',50+50*-switch,'tiny3',50+50*switch,'tiny0',50+50*switch,'tiny1', 50+50*-switch,'movey2',50+50*-switch,'movey3',50+50*switch,'movey0',50+50*switch,'movey1'}
    switch = switch *-1
end
ease{65,0.5,outQuad,0,'flip',0,'invert'}
ease{34,0.5,inQuad,20,'rotationz',100,'invert'}
ease{34.5,0.5,outQuad,100,'reverse0',100,'reverse1'}
ease{35,0.5,inOutQuad,-20,'rotationz',0,'invert'}
ease{35.5,0.5,outQuad,100,'reverse2',100,'reverse3',0,'rotationz'}
ease{40,1,outQuad,0,'reverse2',0,'reverse3',0,'reverse0',0,'reverse1'}
ease{44,1,outQuad,100,'reverse2',100,'reverse3',100,'reverse0',100,'reverse1'}
ease{46,0.5,outQuad,0,'reverse0',0,'reverse1',20,'rotationz'}
ease{46.5,0.5,outQuad,0,'reverse2',0,'reverse3',0,'rotationz'}

ease{50,0.5,outQuad,100,'reverse0',100,'reverse1',-20,'rotationz'}
ease{50.5,0.5,outQuad,100,'reverse2',100,'reverse3',0,'rotationz'}

ease{54,0.5,outQuad,20,'rotationz'}
ease{54.5,0.5,outQuad,0,'reverse0',0,'reverse1'}
ease{55,0.5,outQuad,-20,'rotationz'}
ease{55.5,0.5,outQuad,0,'reverse2',0,'reverse3',0,'rotationz'}
ease{60,1,outQuad,100,'reverse2',100,'reverse3',100,'reverse0',100,'reverse1'}
ease{62,0.5,outQuad,0,'reverse0',0,'reverse1',-20,'rotationz'}
ease{62.5,0.5,outQuad,0,'reverse2',0,'reverse3',0,'rotationz'}