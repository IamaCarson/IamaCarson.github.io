set{124,1.5,'xmod',1,'enable_counter'}
ease{124,1,bounce,-300,'tiny0',30,'confusionoffset0',130,'drunk0',130,'drunkz0'}
ease{124,3,bounce,130,'zoom',100,'drunk',100,'tipsy'}

ease{129,3,bounce,130,'zoom',100,'drunk',100,'tipsy'}

ease{132,1,outQuad,100,'invert'}
ease{124.5,2,bounce,-300,'tiny3',-30,'confusionoffset3',130,'drunk3',130,'drunkz3'}
ease{125,2,bounce,-300,'tiny1',30,'confusionoffset1',130,'drunk1',130,'drunkz1'}
ease{125.5,2,bounce,-300,'tiny2',-30,'confusionoffset2',130,'drunk2',130,'drunkz2'}
ease{124,4,bounce,120,'zoom'}
ease{128,0.5,outQuad,-100,'flip',200,'tiny',200,'noteskewy'}
set{128.5,0,'flip',-200,'noteskewy',0,'rotationz'}
ease{128.5,0.5,outQuad,0,'flip',0,'tiny',0,'noteskewy'}
ease{129,1,bounce,-200,'tiny2',-200,'tiny0'}
ease{129.5,1,bounce,-200,'tiny1',-200,'tiny3'}
ease{130,1,bounce,-200,'tiny2',-200,'tiny0'}

ease{133,1,outQuad,0,'invert'}
ease{133.75,1,outQuad,100,'reverse2',100,'reverse3'}
ease{133.75,0.25,outQuad,-75,'invert',25,'flip'}
ease{134,1,outQuad,100,'reverse0',100,'reverse1'}
ease{134,0.25,outQuad,0,'invert',0,'flip'}

ease{141.75,0.25,outQuad,-75,'invert',25,'flip'}
ease{142,0.25,outQuad,0,'invert',0,'flip'}
ease{149.75,0.25,outQuad,-75,'invert',25,'flip'}
ease{150,0.25,outQuad,0,'invert',0,'flip'}

ease{165.75,0.25,outQuad,100,'invert'}
ease{166,0.25,outQuad,0,'invert'}


for b = 132, 159,1 do
    ease{b,1,bounce,400*switch,'parabolax',30*switch,'rotationz',150,'zoom',-200,'tiny',200,'tipsy',0.3,'fish'}

 switch = switch * -1
end
for b = 135, 143, 1 do
    ease{b,1,outExpo,50+50*switch,'reverse0',50+50*switch,'reverse2',50+50*-switch,'reverse1',50+50*-switch,'reverse3'}
    switch = switch * -1
end
ease{143,1,outExpo,0,'reverse0',0,'reverse1',0,'reverse2',0,'reverse3'}
ease{144,1,outExpo,100,'reverse'}
ease{141.75,0.25,outQuad,-75,'invert',25,'flip'}
ease{142,0.25,outQuad,0,'invert',0,'flip'}

--ease{148,1,inQuad,100,'reverse0',100,'reverse1'}
ease{153,1,inQuad,100,'reverse',0,'reverse2',0,'reverse3',0,'reverse0',0,'reverse1'}
for b = 148, 152, 1 do
    ease{b,1,outExpo,50+50*switch,'reverse0',50+50*-switch,'reverse2',50+50*switch,'reverse1',50+50*-switch,'reverse3'}
    switch = switch * -1
end
for col = 0, 3 do
    ease{146 + 0.5*col,0.5,outQuad,100,'reverse'..3-col}
    ease{154 + 0.5*col,0.5,outQuad,100,'reverse'..col}
    ease{162 + 0.5*col,0.5,outQuad,100,'reverse'..col}
    ease{170 + 0.5*col,0.5,outQuad,0,'reverse'..col}
    ease{178 + 0.5*col,0.5,outQuad,100,'reverse'..col}
    ease{159,1,outQuad,0,'reverse'..col}
end

ease{156,1,outQuad,100,'invert'}
ease{157,1,outQuad,0,'invert'}
ease{158,1,outQuad,100,'flip'}
ease{159,1,outQuad,0,'flip'}
ease{160,1,outQuad,150,'zoom',100,'stealth',100,'dark',0,'reverse',200,'tiny',100,'orient',-30,'rotationz',-400,'parabolax',plr=1}
set{160,0,'zoom',100,'stealth',100,'dark',200,'tiny',100,'reverse',200,'tipsy',plr=2}
ease{160,1,outQuad,100,'zoom',0,'stealth',0,'dark',0,'reverse',0,'tiny',100,'orient',0,'rotationz',0,'parabolax',0,'tipsy',plr=2}
ease{161,0.5,outQuad,200,'tiny0',200,'tiny1',plr=2}
ease{161.5,0.5,outQuad,200,'tiny3',200,'tiny2',plr=2}
set{161,100,'reverse',200,'tiny0',200,'tiny1',200,'tiny2',200,'tiny3',0,'parabolax',0,'rotationz',0,'orient',100,'zoom',0,'stealth',0,'dark',0,'tiny',plr=1}
ease{161,1,inQuad,0,'tiny0',0,'tiny1',plr=1}
ease{161.5,0.5,inQuad,0,'tiny3',0,'tiny2',plr=1}
ease{161.5,2,bounce,130,'zoom',plr=1}
ease{161,2,inOutQuad,180,'rotationy'}
ease{163,1,inOutQuad,360,'rotationy'}
ease{161,2,inOutQuad,40,'rotationz'}
ease{163,1,inOutQuad,0,'rotationz'}
set{163,0,'rotationy'}


--ease{170,1,inQuad,0,'reverse',0,'reverse2',0,'reverse3',0,'reverse0',0,'reverse1'}
for b = 164, 169, 1 do
    ease{b,1,outExpo,50+50*switch,'reverse'}
    ease{b,1,bounce,400*switch,'parabolax',30*switch,'rotationz',130,'zoom',-200,'tiny',200,'tipsy',0.5,'fish'}
    switch = switch * -1
end
ease{170,2,bounce,400*switch,'parabolax',30*switch,'rotationz',130,'zoom',-200,'tiny',200,'tipsy'}
ease{172,1,outQuad,0,'reverse'}
ease{172,1,bounce,-400*switch,'parabolax',-30*switch,'rotationz',130,'zoom',-200,'tiny',200,'tipsy'}
ease{173,1,outQuad,100,'reverse'}
ease{173,1,bounce,400*switch,'parabolax',30*switch,'rotationz',130,'zoom',-200,'tiny',200,'tipsy'}
ease{174,1,outQuad,0,'reverse'}
ease{174,1,bounce,-400*switch,'parabolax',-30*switch,'rotationz',130,'zoom',-200,'tiny',200,'tipsy'}
ease{175,1,outQuad,0,'reverse',0,'reverse0',0,'reverse1',0,'reverse2',0,'reverse3'}
ease{175,1,bounce,400*switch,'parabolax',30*switch,'rotationz',130,'zoom',-200,'tiny',200,'tipsy'}
set{176,0,'tiny0',0,'tiny1',0,'tiny2',0,'tiny3',}
ease{176,1,outQuad,250,'movex',100,'reverse',0,'orient',plr=1}
set{177,0,'reverse2',0,'reverse3',0,'reverse0',0,'reverse1'}
ease{176,1,outQuad,-250,'movex',0,'orient',plr=2}
set{180,0,'reverse2',0,'reverse3',0,'reverse0',0,'reverse1',0,'orient',100,'reverse',plr=1}
set{180,0,'reverse2',0,'reverse3',0,'reverse0',0,'reverse1',0,'orient',plr=2}

ease{176,1,bounce,130,'zoom',-100,'tiny'}
ease{177,1,outQuad,0,'reverse',plr=1}
ease{177,1,outQuad,100,'reverse',plr=2}
switch = 1
for b = 180, 191, 1 do
    ease{b,1,outExpo,50+(50*switch),'reverse',plr=1}
    ease{b,1,bounce,400*switch,'parabolax',30*switch,'rotationz',110,'zoom',-200,'tiny',200,'tipsy',plr=1}
   ease{b,1,outExpo,50+(50*-switch),'reverse',plr=2}
    ease{b,1,bounce,400*switch,'parabolax',30*switch,'rotationz',110,'zoom',-200,'tiny',-200,'tipsy',plr=2}
    switch = switch * -1
end
perframe{124,131, function(b,p)
    bgColor:diffuse(sin(b)/2+0.5,cos(b)/2+0.5,tan(b)/2+0.5,1)
    my_sprite2:rotationx(sin(b/2)*30)
    my_sprite2:rotationz(2)
    my_sprite2:rotationy(cos(b/2)*30)
    
  end}

perframe{132,193, function(b,p)
    bgColor:diffuse(sin(b)/2+0.5,cos(b)/2+0.5,tan(b)/2+0.5,1)
    my_sprite2:rotationx(sin(b)*30)
    my_sprite2:rotationz(sin(b))
    my_sprite2:rotationy(cos(b)*30)
end}