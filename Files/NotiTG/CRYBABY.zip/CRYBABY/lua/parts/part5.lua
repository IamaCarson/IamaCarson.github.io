ease{192,1,inQuad,0,'reverse',0,'reverse2',0,'reverse3',0,'reverse0',0,'reverse1'}
ease{192,1,inQuad,0,'reverse',0,'reverse2',0,'reverse3',0,'reverse0',0,'reverse1',0,'movex',plr=1}
ease{192,1,inQuad,0,'reverse',0,'reverse2',0,'reverse3',0,'reverse0',0,'reverse1',0,'movex',plr=2}
ease{192,1,bounce,130,'zoom',200,'tipsy',-10,'flip'}

ease{193,3,bounce,130,'zoom'}
ease{193,1,bounce,20,'rotationz',-100,'tiny'}
ease{193.5,1,bounce,-20,'rotationz',-100,'tiny'}

ease{194,1,outQuad,25,'flip',-75,'invert',100,'reverse0',100,'reverse1'}
ease{194,1,bounce,100,'drunk',20,'rotationz',30,'rotationy',-100,'tiny',100,'parabolax'}

ease{195,1,outQuad,0,'flip',0,'invert',100,'reverse2',100,'reverse3'}
ease{195,1,bounce,-100,'drunk',-20,'rotationz',-30,'rotationy',-100,'tiny',-100,'parabolax'}

ease{195.5,1,bounce,20,'rotationz',-100,'tiny',50,'drunk',20,'rotationy'}
ease{196,1,bounce,-20,'rotationz',-100,'tiny',-50,'drunk',-20,'rotationy'}
ease{196.5,1,bounce,20,'rotationz',-100,'tiny',50,'drunk',20,'rotationy'}
ease{197,1,bounce,-20,'rotationz',-100,'tiny',-50,'drunk',-20,'rotationy'}



ease{198,1,outQuad,100,'invert',0,'reverse0',0,'reverse1'}
ease{198,1,bounce,100,'drunk',20,'rotationz',30,'rotationy',-100,'tiny',100,'parabolax'}
ease{199,1,outQuad,0,'invert',0,'reverse2',0,'reverse3'}
ease{199,1,bounce,-100,'drunk',-20,'rotationz',-30,'rotationy',-100,'tiny',-100,'parabolax'}
ease{200,1,bounce,100,'drunk',20,'rotationz',30,'rotationy',-100,'tiny',100,'parabolax'}

ease{201,3,bounce,130,'zoom'}
ease{201,1,bounce,-20,'rotationz',-100,'tiny'}
ease{201.5,1,bounce,20,'rotationz',-100,'tiny'}

ease{202,1,outQuad,25,'flip',-75,'invert',100,'reverse0',100,'reverse1'}
ease{202,1,bounce,100,'drunk',20,'rotationz',30,'rotationy',-100,'tiny',100,'parabolax'}

ease{203,1,outQuad,0,'flip',0,'invert',100,'reverse2',100,'reverse3'}
ease{203,1,bounce,-100,'drunk',-20,'rotationz',-30,'rotationy',-100,'tiny',-100,'parabolax'}

ease{203.5,1,bounce,20,'rotationz',-100,'tiny',50,'drunk',20,'rotationy'}
ease{204,1,bounce,-20,'rotationz',-100,'tiny',-50,'drunk',-20,'rotationy'}
ease{204.5,1,bounce,20,'rotationz',-100,'tiny',50,'drunk',20,'rotationy'}
ease{205,1,bounce,-20,'rotationz',-100,'tiny',-50,'drunk',-20,'rotationy'}

ease{206,1,outQuad,100,'invert',0,'reverse0',0,'reverse1'}
ease{206,1,bounce,100,'drunk',20,'rotationz',30,'rotationy',-100,'tiny',100,'parabolax'}
ease{207,1,outQuad,0,'invert',0,'reverse2',0,'reverse3'}
ease{207,1,bounce,-100,'drunk',-20,'rotationz',-30,'rotationy',-100,'tiny',-100,'parabolax'}
ease{208,1,bounce,100,'drunk',20,'rotationz',30,'rotationy',-100,'tiny',100,'parabolax'}


ease{209,1,bounce,-20,'rotationz',-100,'tiny'}
ease{209.5,1,bounce,20,'rotationz',-100,'tiny'}
ease{208,1,outQuad,100,'reverse'}

ease{210,1,outQuad,25,'flip',-75,'invert',100,'reverse0',100,'reverse1'}
ease{210,1,bounce,100,'drunk',20,'rotationz',30,'rotationy',-100,'tiny',100,'parabolax'}

ease{211,1,outQuad,0,'flip',0,'invert',100,'reverse2',100,'reverse3'}
ease{211,1,bounce,-100,'drunk',-20,'rotationz',-30,'rotationy',-100,'tiny',-100,'parabolax'}

ease{211.5,1,bounce,20,'rotationz',-100,'tiny',50,'drunk',20,'rotationy'}
ease{212,1,bounce,-20,'rotationz',-100,'tiny',-50,'drunk',-20,'rotationy'}
ease{212.5,1,bounce,20,'rotationz',-100,'tiny',50,'drunk',20,'rotationy'}
ease{213,1,bounce,-20,'rotationz',-100,'tiny',-50,'drunk',-20,'rotationy'}

ease{214,1,outQuad,100,'invert',0,'reverse0',0,'reverse1'}
ease{214,1,bounce,100,'drunk',20,'rotationz',30,'rotationy',-100,'tiny',100,'parabolax'}

ease{215,1,outQuad,0,'invert',0,'reverse2',0,'reverse3'}
ease{215,1,bounce,-100,'drunk',-20,'rotationz',-30,'rotationy',-100,'tiny',-100,'parabolax'}

ease{216,1,bounce,-20,'rotationz',-100,'tiny'}
ease{216.5,1,bounce,20,'rotationz',-100,'tiny'}

ease{217,1,outQuad,25,'flip',-75,'invert',100,'reverse0',100,'reverse1'}
ease{217,1,bounce,100,'drunk',20,'rotationz',30,'rotationy',-100,'tiny',100,'parabolax'}

ease{218,1,outQuad,0,'flip',0,'invert',100,'reverse2',100,'reverse3'}
ease{218,1,bounce,-100,'drunk',-20,'rotationz',-30,'rotationy',-100,'tiny',-100,'parabolax'}

ease{219,1,bounce,20,'rotationz',-100,'tiny'}
ease{219.5,1,bounce,-20,'rotationz',-100,'tiny'}

add{220,1,bounce,100,'drunk',20,'rotationz',30,'rotationy',-100,'tiny',100,'parabolax'}

add{221,1,bounce,-100,'drunk',-20,'rotationz',-30,'rotationy',-100,'tiny',-100,'parabolax'}
add{222,1,bounce,100,'drunk',20,'rotationz',30,'rotationy',-100,'tiny',100,'parabolax'}

add{223,1,bounce,-100,'drunk',-20,'rotationz',-30,'rotationy',-100,'tiny',-100,'parabolax'}

add{225,1,bounce,-20,'rotationz',-100,'tiny'}
add{225.5,1,bounce,20,'rotationz',-100,'tiny'}

add{226,1,outQuad,0,'invert',100,'reverse0',100,'reverse1'}
add{226,1,bounce,100,'drunk',20,'rotationz',30,'rotationy',-100,'tiny',100,'parabolax'}

add{227,1,outQuad,0,'invert',100,'reverse2',100,'reverse3'}
add{227,1,bounce,-100,'drunk',-20,'rotationz',-30,'rotationy',-100,'tiny',-100,'parabolax'}

add{227.5,1,bounce,20,'rotationz',-100,'tiny',50,'drunk',20,'rotationy'}
add{228,1,bounce,-20,'rotationz',-100,'tiny',-50,'drunk',-20,'rotationy'}
add{228.5,1,bounce,20,'rotationz',-100,'tiny',50,'drunk',20,'rotationy'}
add{229,1,bounce,-20,'rotationz',-100,'tiny',-50,'drunk',-20,'rotationy'}

ease{224,1,outQuad,0,'reverse'}
ease{230,1,outQuad,100,'reverse0',100,'reverse1'}
add{230,1,bounce,100,'drunk',30,'zoom',-100,'tiny',10,'rotationz'}
ease{231,1,outQuad,100,'reverse2',100,'reverse3'}
add{231,1,bounce,100,'drunk',30,'zoom',-100,'tiny',10,'rotationz'}

set{232,0,'reverse0',0,'reverse1',0,'reverse2',0,'reverse3',100,'reverse'}
add{232,1,bounce,100,'drunk',20,'rotationz',30,'rotationy',-100,'tiny',100,'parabolax'}

add{233,1,bounce,-20,'rotationz',-100,'tiny'}
add{233.5,1,bounce,20,'rotationz',-100,'tiny'}

ease{238,1,outQuad,100,'reverse0',100,'reverse1'}
ease{239,1,outQuad,100,'reverse2',100,'reverse3'}
ease{240,1,outQuad,0,'reverse0',0,'reverse1',0,'reverse2',0,'reverse3',100,'reverse'}

ease{246,1,outQuad,100,'reverse0',100,'reverse1'}
ease{247,1,outQuad,100,'reverse2',100,'reverse3'}
ease{248,1,outCubic,0,'reverse0',0,'reverse1',0,'reverse2',0,'reverse3',0,'reverse'}

ease{234,1,outQuad,100,'reverse0',100,'reverse1'}
add{234,1,bounce,100,'drunk',30,'zoom',-100,'tiny',10,'rotationz'}
ease{235,1,outQuad,100,'reverse2',100,'reverse3'}
add{235,1,bounce,100,'drunk',30,'zoom',-100,'tiny',10,'rotationz'}

add{235.5,1,bounce,20,'rotationz',-100,'tiny',50,'drunk',20,'rotationy'}
add{236,1,bounce,-20,'rotationz',-100,'tiny',-50,'drunk',-20,'rotationy'}
add{236.5,1,bounce,20,'rotationz',-100,'tiny',50,'drunk',20,'rotationy'}
add{237,1,bounce,-20,'rotationz',-100,'tiny',-50,'drunk',-20,'rotationy'}

ease{238,1,outQuad,100,'reverse0',100,'reverse1'}
add{238,1,bounce,100,'drunk',30,'zoom',-100,'tiny',10,'rotationz'}
ease{239,1,outQuad,100,'reverse2',100,'reverse3'}
add{239,1,bounce,-100,'drunk',30,'zoom',-100,'tiny',-10,'rotationz'}

add{241,1,bounce,-20,'rotationz',-100,'tiny',100,'drunk'}
add{241.5,1,bounce,20,'rotationz',-100,'tiny',-100,'drunk'}
add{242,1,bounce,-20,'rotationz',-100,'tiny',100,'drunk'}
ease{242,1,outQuad,0,'reverse'}

add{243.5,1,bounce,20,'rotationz',-100,'tiny',100,'drunk',40,'rotationy'}
add{244,1,bounce,-20,'rotationz',-100,'tiny',-100,'drunk',-40,'rotationy'}
add{244.5,1,bounce,20,'rotationz',-100,'tiny',100,'drunk',40,'rotationy'}
add{245,1,bounce,-20,'rotationz',-100,'tiny',-100,'drunk',-40,'rotationy'}

ease{245,1,outQuad,100,'reverse0',100,'reverse1'}
add{245,1,bounce,100,'drunk',30,'zoom',-100,'tiny',10,'rotationz',0,'rotationy'}
ease{246,1,outQuad,100,'reverse2',100,'reverse3'}
add{246,1,bounce,-100,'drunk',30,'zoom',-100,'tiny',-10,'rotationz',0,'rotationy'}
add{247,1,bounce,-100,'drunk',30,'zoom',-100,'tiny',30,'rotationz',0,'rotationy'}

add{248,1,bounce,-20,'rotationz',-100,'tiny',0,'rotationy',100,'drunk'}
add{248.5,1,bounce,20,'rotationz',0,'rotationy',-100,'tiny',-100,'drunk'}
ease{249,1,outCubic,0,'reverse0',0,'reverse1',0,'reverse2',0,'reverse3',0,'reverse'}
add{251,1,bounce,30,'rotationz',-100,'tiny',0,'rotationy',100,'drunk'}
add{251.5,1,bounce,-30,'rotationz',-100,'tiny',0,'rotationy',-100,'drunk'}


ease{254,1,outCubic,100,'split'}ease{255,1,outCubic,100,'alternate'}
ease{256,1,outQuad,0,'split',0,'alternate',100,'reverse'}


ease{249,1,outQuad,100,'reverse0',100,'reverse1'}
add{249,1,bounce,100,'drunk',30,'zoom',-100,'tiny',10,'rotationz',0,'rotationy'}
ease{250,1,outQuad,100,'reverse2',100,'reverse3'}
add{250,1,bounce,-100,'drunk',30,'zoom',-100,'tiny',-10,'rotationz',0,'rotationy'}

ease{252,1,outQuad,100,'reverse0',100,'reverse1'}
add{252,1,bounce,100,'drunk',30,'zoom',-100,'tiny',10,'rotationz',0,'rotationy'}
ease{253,1,outQuad,100,'reverse2',100,'reverse3'}
add{253,1,bounce,-100,'drunk',30,'zoom',-100,'tiny',-10,'rotationz',0,'rotationy'}

ease{254,1,outQuad,100,'reverse0',100,'reverse1'}
add{254,1,bounce,100,'drunk',30,'zoom',-100,'tiny',10,'rotationz',0,'rotationy'}
ease{255,1,outQuad,100,'reverse2',100,'reverse3'}
add{255,1,bounce,-100,'drunk',30,'zoom',-100,'tiny',-10,'rotationz',0,'rotationy'}

add{256,3,pop,200,'drunk',50,'zoom',-150,'tiny',20,'rotationz',0,'rotationy',-10,'flip',20,'rotationx'}


set{196,-700,'movex',plr=1}
flip = 1
a = 0
for b = 196, 252, 4 do
    ease{b,2,bounce,130,'zoom',plr=1}
    ease{b,2,outQuad,0,'movex',plr=1}
    ease{b+2,2,bounce,130,'zoom',plr=1}
    ease{b+2,2,outQuad,700*flip,'movex',plr=1}
    set{b+4,-700*flip,'movex',plr=1}

    ease{b,2,bounce,130,'zoom',plr=2}
    ease{b,2,outQuad,700*flip,'movex',plr=2}
    set{b+2,-700*flip,'movex',plr=2}
    ease{b+2,2,bounce,130,'zoom',plr=2}
    ease{b+2,2,outQuad,0,'movex',plr=2}
    a = a + 1
    if a == 2 then
        a = 0
        flip = flip * -1
    end
end
for b = 220, 224, 1 do
 add{b,1,outExpo,-360/5,'rotationz'}
 ease{b,1,bounce,-100,'tiny'}
end
for b = 225, 229, 1 do
    add{b,1,outExpo,360/5*-1,'rotationx'}
   end
   for b = 232, 237, 1 do
    add{b,1,outExpo,360/6*-1,'rotationx'}
   end
   for b = 240, 244, 1 do
    add{b,1,outExpo,180/5*1,'rotationx'}
   end
   for b = 245, 252, 1 do
    add{b,1,outExpo,180/8*1,'rotationx'}
   end
set{253,0,'rotationx',0,'rotationy'}
set{256,0,'movex',plr=1}
set{256,0,'movex',plr=2}

perframe{193,257, function(b,p)
    bgColor:diffuse(sin(b)/2+0.5,cos(b)/2+0.5,tan(b)/2+0.5,p[1].lmao)
    my_sprite2:rotationx(sin(b/4)*30)
    my_sprite2:rotationz(sin(b/4))
    my_sprite2:rotationy(cos(b/4)*10)
end}
set{193,1,'lmao'}
ease{256,1,outQuad,0,'lmao'}
ease{260,1,outQuad,1,'lmao'}
ease{288,1,outQuad,0,'lmao'}
ease{292,1,outQuad,1,'lmao'}ease{319,1,outQuad,0,'lmao'}

perframe{260,289, function(b,p)
    bgColor:diffuse(sin(b)/2+0.5,cos(b)/2+0.5,tan(b)/2+0.5,p[1].lmao)
    my_sprite2:rotationx(sin(b/4)*30)
    my_sprite2:rotationz(sin(b/4)*5)
    my_sprite2:rotationy(cos(b/4)*30)
end}

perframe{292,320, function(b,p)
    bgColor:diffuse(sin(b)/2+0.5,cos(b)/2+0.5,tan(b)/2+0.5,p[1].lmao)
    my_sprite2:rotationx(sin(b/4)*30)
    my_sprite2:rotationz(sin(b/4)*20)
    my_sprite2:rotationy(sin(b/4)*30)
end}