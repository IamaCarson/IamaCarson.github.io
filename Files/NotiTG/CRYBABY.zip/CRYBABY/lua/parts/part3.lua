ease{64,1,inOutQuad,0,'reverse0',0,'reverse1',0,'reverse2',0,'reverse3'}

local wib={65,65.5,66,67,68,68.5,69,69.5,70,71,73,73.5,74,75,76,76.5,77,77.5,78,79,81,81.5,82,83,84,84.5,85,85.5,86,87,88.5,89,89.5,90.5,91,91.5,92,93,94,95,96}
switch = 1
for i,v in ipairs(wib) do
    ease{v,1,outQuart,100*switch,'drunk',100*switch,'parabolax',100*switch,'tipsy',10,'land'}
    switch = switch * -1
  end
  ease{97,1,outQuad,0,'drunk',0,'tipsy',0,'land',0,'parabolax',1,'enable_counter'}
  for b = 96, 111, 1 do
    add{b,1,inOutQuart,360*2/(112-96),'rotationz',plr=1}
    add{b,1,inOutQuart,360*2/(112-96)*-1,'rotationz',plr=2}
    ease{b,1,pop,-10,'flip',-100,'tiny',200,'zoomz',-1000,'tinyz',130,'zoom',-10,'flip',50,'tipsy'}
  end
  for b = 112, 120, 0.5 do
    ease{b,0.5,bounce,200*switch,'tiny0',200*switch,'tiny2',-200*switch,'tiny1',-200*switch,'tiny3'}
    switch = switch * -1
  end
  for b = 112, 120, 1 do
    ease{b,1,bounce,50*switch,'movey0',50*switch,'movey2',-50*switch,'movey1',50*switch,'movey3'}
  end
  for b = 120, 124, 0.25 do
    ease{b,0.25,bounce,200*switch,'tiny0',200*switch,'tiny2',-200*switch,'tiny1',-200*switch,'tiny3'}
    switch = switch * -1
  end
ease{65,1,outQuad,1,'lmao'}
perframe{65,96, function(b,p)
  for plr = 1,2 do
  p[plr].movex = p[plr].movex + sin(b)*100*p[1].lmao
  p[plr].rotationy = p[plr].rotationy + cos(b)*30*p[1].lmao
  p[plr].rotationz = p[plr].rotationz + sin(b/2)*30*p[1].lmao

  end
  
end}
ease{95,1,inQuad,0,'lmao'}
perframe{96,112,function(b,p)
  bgColor:diffuse(sin(b)/2+0.5,cos(b)/2+0.5,tan(b)/2+0.5,1)
  my_sprite2:rotationx(sin(b/2)*10)
  my_sprite2:rotationz(sin(b/2))
  my_sprite2:rotationy(sin(b/2)*10)
end}
perframe{112,120,function(b,p)
  bgColor:diffuse(sin(b)/2+0.5,cos(b)/2+0.5,tan(b)/2+0.5,1)
  my_sprite2:rotationx(sin(b)*20)
  my_sprite2:rotationz(sin(b)*5)
  my_sprite2:rotationy(sin(b)*20)
end}
perframe{120,124,function(b,p)
  bgColor:diffuse(sin(b)/2+0.5,cos(b)/2+0.5,tan(b)/2+0.5,1)
  my_sprite2:rotationx(sin(b*2)*30)
  my_sprite2:rotationz(sin(b*2)*10)
  my_sprite2:rotationy(sin(b*2)*30)
end}