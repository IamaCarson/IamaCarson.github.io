aux{'lmao'}
definemod{'bgaftz', function(p)
    my_sprite2:zoom(p)
end}
definemod{'bgafta', function(p)
    my_sprite2:diffusealpha(p)
end}
definemod{'bgaftrz', function(p)
    my_sprite2:rotationz(p)
end}

setdefault{
100, 'zoom',
2, 'xmod',
50,'flip',
0, 'lmao',
1,'zbuffer',
0,'movey',
0.99, 'bgaftz',
0.99, 'bgafta',
}
ease{0,2,outQuad,1,'lmao'}
ad = 0.8
yr = 100
xr = 270
xp = 2.3
yp = 1.3
xc1 = 1

ad2 = 0.1
yr2 = 10
xr2 = 40
xp2 = 2.3
yp2 = 1.3
xc12 = 1

px = 400
perframe{0,30,function(b,p)
    bgColor:diffuse(sin(b)/2+0.5,cos(b)/2+0.5,tan(b)/2+0.5,0.7*p[1].lmao)
    my_sprite2:rotationx(sin(b/2)*20)
    my_sprite2:rotationz(sin(b/2)*5)
    my_sprite2:rotationy(cos(b/2)*10)
    p[1].movex0 = sin(b/xp*xc1)*xr*p[1].lmao
    p[1].movey0 = cos(b/yp)*yr*p[1].lmao
    p[1].movex1 = sin(b/xp+ad)*xr*p[1].lmao
    p[1].movey1 = cos(b/yp+ad)*yr*p[1].lmao
    p[1].movex2 = sin(b/xp*xc1+ad*2)*xr*p[1].lmao
    p[1].movey2 = cos(b/yp+ad*2)*yr*p[1].lmao
    p[1].movex3 = sin(b/xp+ad*3)*xr*p[1].lmao
    p[1].movey3 = cos(b/yp+ad*3)*yr*p[1].lmao
    p[2].movex0 = sin(b/xp*xc1+ad*4)*xr*p[1].lmao
    p[2].movey0 = cos(b/yp+ad*4)*yr*p[1].lmao
    p[2].movex1 = sin(b/xp+ad*5)*xr*p[1].lmao
    p[2].movey1 = cos(b/yp+ad*5)*yr*p[1].lmao
    p[2].movex2 = sin(b/xp*xc1+ad*6)*xr*p[1].lmao
    p[2].movey2 = cos(b/yp+ad*6)*yr*p[1].lmao
    p[2].movex3 = sin(b/xp+ad*7)*xr*p[1].lmao
    p[2].movey3 = cos(b/yp+ad*7)*yr*p[1].lmao



    p[1].noteskewx0 = sin(b/xp2*xc12)*xr2*p[1].lmao
    p[1].noteskewy0 = cos(b/yp2)*yr2*p[1].lmao
    p[1].noteskewx1 = sin(b/xp2+ad)*xr2*p[1].lmao
    p[1].noteskewy1 = cos(b/yp2+ad)*yr2*p[1].lmao
    p[1].noteskewx2 = sin(b/xp2*xc12+ad2*2)*xr2*p[1].lmao
    p[1].noteskewy2 = cos(b/yp2+ad2*2)*yr2*p[1].lmao
    p[1].noteskewx3 = sin(b/xp2+ad2*3)*xr2*p[1].lmao
    p[1].noteskewy3 = cos(b/yp2+ad2*3)*yr2*p[1].lmao
    p[2].noteskewx0 = sin(b/xp2*xc12+ad2*4)*xr2*p[1].lmao
    p[2].noteskewy0 = cos(b/yp2+ad2*4)*yr2*p[1].lmao
    p[2].noteskewx1 = sin(b/xp2+ad2*5)*xr2*p[1].lmao
    p[2].noteskewy1 = cos(b/yp2+ad2*5)*yr2*p[1].lmao
    p[2].noteskewx2 = sin(b/xp2*xc12+ad2*6)*xr2*p[1].lmao
    p[2].noteskewy2 = cos(b/yp2+ad2*6)*yr2*p[1].lmao
    p[2].noteskewx3 = sin(b/xp2+ad2*7)*xr2*p[1].lmao
    p[2].noteskewy3 = cos(b/yp2+ad2*7)*yr2*p[1].lmao
    p[1].parabolax = cos(b/yp2+ad2*7)*px*p[1].lmao
    p[2].parabolax = cos(b/yp2+ad2*7)*px*p[1].lmao
            
end}
for col = 0, 3 do
    setdefault{200,'tiny'..col,-10,'drunkperiod'..col}
    add{3.5+(col+1)/3,1,outQuad,-200,'tiny'..col}
end
mcol = 0
for b = 0, 4, 0.5 do
    ease{b,2,pop,-500/(b+1),'tiny'..mcol}
    mcol = mcol + 1
    if mcol == 4 then mcol = 0 end
end
ease{8,2,outQuad,1000,'movey0',100,'reverse0'}
ease{12,2,outQuad,1000,'movey1',100,'reverse1'}
ease{16,2,outQuad,1000,'movey2',100,'reverse2'}
ease{20,2,outQuad,1000,'movey3',100,'reverse3'}
ease{24,2,outQuad,0,'movey0',0,'reverse0',0,'movey1',0,'reverse1'}
ease{27,2,outQuad,0,'movey2',0,'reverse2',0,'movey3',0,'reverse3'}
ease{27,4,outQuad,0,'lmao',0,'flip'}

