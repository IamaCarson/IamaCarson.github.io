local function throw(msg)
    local _, err = pcall(error, msg, 4)
    error(err)
end


--committing math.sin but without the math. (for everything else too)
for i in pairs(math) do xero[i] = i ~= 'type' and math[i] or nil end

--counter rotation machine go brrrrrrr
--now with enable mod
alias {'confusionzoffset', 'confusionoffset'}
aux {'enable_counter'}
node {
    'enable_counter','rotationx', 'rotationy', 'rotationz',
    'confusionxoffset', 'confusionyoffset', 'confusionoffset',
    function(ec,rx, ry, rz, cx, cy, cz)
        if ec==0 then
            return cx,cy,cz
        else
            -- transform axes
            rx, rz = rz, rx
            cx, cz = cz, cx
            
            -- helpers for r
            local rcosx, rcosy, rcosz, rsinx, rsiny, rsinz =
                cos(rx / 360 * pi), cos(ry / 360 * pi), cos(rz / 360 * pi),
                sin(rx / 360 * pi), sin(ry / 360 * pi), sin(rz / 360 * pi)
            
            -- r to quaternion
            local ra, rb, rc, rd =
                rcosx*rcosy*rcosz-rsinx*rsiny*rsinz,
                rsinx*rsiny*rcosz+rcosx*rcosy*rsinz,
                rsinx*rcosy*rcosz+rcosx*rsiny*rsinz,
                rcosx*rsiny*rcosz-rsinx*rcosy*rsinz
            
            -- helpers for c
            local ccosx, ccosy, ccosz, csinx, csiny, csinz =
                cos(cx/200), cos(cy/200), cos(cz/200),
                sin(cx/200), sin(cy/200), sin(cz/200)
            
            -- c to quaternion
            local ca, cb, cc, cd =
                ccosx*ccosy*ccosz-csinx*csiny*csinz,
                csinx*csiny*ccosz+ccosx*ccosy*csinz,
                csinx*ccosy*ccosz+ccosx*csiny*csinz,
                ccosx*csiny*ccosz-csinx*ccosy*csinz
            
            -- o = c * inverse(r)
            local oa, ob, oc, od =
                ca*ra+cb*rb+cc*rc+cd*rd,
                -ca*rb+cb*ra-cc*rd+cd*rc,
                -ca*rc+cb*rd+cc*ra-cd*rb,
                -ca*rd-cb*rc+cc*rb+cd*ra
            
            -- o to euler angles
            local ox, oy, oz =
                100 * atan2(2*oc*oa-2*ob*od, 1-2*oc*oc-2*od*od),
                100 * asin(2*ob*oc+2*od*oa),
                100 * atan2(2*ob*oa-2*oc*od, 1-2*ob*ob-2*od*od)
            
            -- transform axes
            ox, oz = oz, ox
            return ox, oy, oz
        end
    end,
    'confusionxoffset', 'confusionyoffset', 'confusionoffset',
}
--get y pos of receptors for standard and reverse from theme
--revmya is movey amount to make 50 reverse be at either end for fancy reverse effects
--SEE: Worm
plryr=tonumber(THEME:GetMetric('Player','ReceptorArrowsYReverse'))
plrys=tonumber(THEME:GetMetric('Player','ReceptorArrowsYStandard'))
plryoff=(plryr+plrys)/2
revmya=200+plryoff

-- AFT Multiplier
aftMult = 1
detectNV = false
if string.find(string.lower(PREFSMAN:GetPreference('LastSeenVideoDriver')), 'nvidia') or string.find(string.lower(DISPLAY:GetVendor()),'nvidia') then
    Trace('NVidia graphics driver detected.')
    Trace('AFT multiplier set to 0.9.')
    detectNV = true
    aftMult = 0.9
else
    Trace('No NVidia graphics driver detected.')
    Trace('AFT multiplier is 1.0.')
end

--hidden regions and hidenoteflashes in 1 function call
function hidewnf(beat,len,plr)
    if not plr then plr={1,2} end
    hide{beat,len,plr=plr}
    set{beat-0.05,100,'hidenoteflashes',plr=plr}
    set{beat-0.05+len,0,'hidenoteflashes',plr=plr}
end

--hide column and flashes for that column
function hcflash(beat,len,cols,plr)
    local plr=plr or rawget(xero, 'plr')
    if type(cols)=='number' then cols={cols} end
    for _,col in pairs(cols) do
        set{beat,100,'hidenoteflashes'..col,plr=plr}
        set{beat+len,0,'hidenoteflashes'..col,plr=plr}
    end
end

--aft uv stuff

function poly_npot(val)
    local out = 2
    while out < val do
        out = out*2
    end
    return out
end

umult=dw/poly_npot(dw)
vmult=dh/poly_npot(dh)

--set position of vertex and map uvs based on display width and height
function setPolyVertPos(poly,index,x,y,z)
    local z = z or 0
    poly:SetVertexPosition(index,x,y,z)
    poly:SetVertexTexCoord(index, umult*((poly:GetX()+x)/bw),vmult-(vmult*((poly:GetY()+y)/bh)))
end

--notflip/notinvert (thanks taro)
definemod{'flip2',function(v)
    return v, -v
end,'flip','notflip'}
definemod{'invert2',function(v)
    return v, -v
end,'invert','notinvert'}

definemod {
    'notinvert',
    function(val)
        return -val, val, -val, val
    end,
    'cosinebumpycx0','cosinebumpycx1','cosinebumpycx2','cosinebumpycx3'
}
definemod {
    'notflip',
    function(val)
        return -val*3, -val, val, val*3
    end,
    'cosinebumpycx0','cosinebumpycx1','cosinebumpycx2','cosinebumpycx3'
}

for i=0,3 do
    local i = i
    definemod {
        'cosinebumpycx'..i,
        function(val)
            return (val * (32/40)), (-val/2)
        end,
        'bumpyx'..i,'movex'..i,
    }
    definemod {
        'cosinebumpyx'..i,
        function(val)
            return (val * (32/40))
        end,
        'bumpyx'..i,
    }
    definemod {
        'cosinebumpyxperiod'..i,
        function(val)
            local bxp = val
            local bxo = ((bxp/100)+1) * (pi*8)
            return bxp, bxo
        end,
        'bumpyxperiod'..i,'bumpyxoffset'..i,
    }
end

--more fancy definemods
--combine tiny stuff
definemod{'tinyall',function(p) return p,p end,'tiny','tinyz'}
definemod{'tinyxz',function(p) return p,p end,'tinyx','tinyz'}
definemod{'tinyyz',function(p) return p,p end,'tinyy','tinyz'}
for col=0,3 do
    definemod{'tinyall'..col,function(p) return p,p end,'tiny'..col,'tinyz'..col}
    definemod{'tinyxz'..col,function(p) return p,p end,'tinyx'..col,'tinyz'..col}
    definemod{'tinyyz'..col,function(p) return p,p end,'tinyy'..col,'tinyz'..col}    
end
definemod{'vibx','viby','vibz',function(x,y,z) return rand.float(x)-(x*.5),rand.float(y)-(y*.5),rand.float(z)-(z*.5) end,'movex','movey','movez'}
for col=0,3 do
    definemod{'vibx'..col,'viby'..col,'vibz'..col,function(x,y,z) return rand.float(x)-(x*.5),rand.float(y)-(y*.5),rand.float(z)-(z*.5) end,'movex'..col,'movey'..col,'movez'..col}
end

definemod{'vibscreenx','vibscreeny','vibscreenz',function(x,y,z) outerFrame:x(rand.float(x)-(x*.5)) outerFrame:y(rand.float(y)-(y*.5)) outerFrame:z(rand.float(z)-(z*.5)) end}

--custom mirroring functions
function mease(t)
    local plrset=t.plr or {1,2}
    if #plrset>2 then
        throw('mease has to be exactly 2 players')
    end
    local tp1=copy(t)
    tp1.plr=plrset[1]
    local tp2=copy(t)
    tp2.plr=plrset[2]
    local i=4
    while tp2[i] do
        if type(tp2[i])=='number' then
            tp2[i]=-tp2[i]
        else
            throw(tp2[i]..' is not a valid percent')
        end
        i=i+2
    end
    ease(tp1)
    ease(tp2)
end

function madd(t)
    local plrset=t.plr or {1,2}
    if #plrset>2 then
        throw('madd has to be exactly 2 players')
    end
    local tp1=copy(t)
    tp1.plr=plrset[1]
    local tp2=copy(t)
    tp2.plr=plrset[2]
    local i=4
    while tp2[i] do
        if type(tp2[i])=='number' then
            tp2[i]=-tp2[i]
        else
            throw(tp2[i]..' is not a valid percent')
        end
        i=i+2
    end
    add(tp1)
    add(tp2)
end

function mset(t)
    local plrset=t.plr or {1,2}
    if #plrset>2 then
        throw('mset has to be exactly 2 players')
    end
    local tp1=copy(t)
    tp1.plr=plrset[1]
    local tp2=copy(t)
    tp2.plr=plrset[2]
    local i=2
    while tp2[i] do
        if type(tp2[i])=='number' then
            tp2[i]=-tp2[i]
        else
            throw(tp2[i]..' is not a valid percent')
        end
        i=i+2
    end
    set(tp1)
    set(tp2)
end
--ease from to (thanks taro)
function easeft(tab)
    local beat,len,eas = tab[1],tab[2],tab[3]
    
    local newtab1 = {beat,plr=tab.plr}
    local newtab2 = {beat+.001,len-.001,eas,plr=tab.plr}
    
    local err = false
    
    if #tab % 2 ~= 1 then
        err = true
        throw('easeft: value/mod pair mismatch!')
    else
        for j=4,#tab,2 do
            local amt,mods = tab[j],tab[j+1]
            
            if type(amt) ~= 'table' then
                err = true
                throw('easeft: mod amount is not a table!')
            else
                table.insert(newtab1,amt[1])
                table.insert(newtab1,mods)
                table.insert(newtab2,amt[2])
                table.insert(newtab2,mods)
            end
        end
    end
    
    if not err then
        set(newtab1)
        ease(newtab2)
    end
    
end
--mease from to
function measeft(tab)
    local beat,len,eas = tab[1],tab[2],tab[3]
    local plrset=t.plr or {1,2}
    if #plrset>2 then
        throw('measeft has to be exactly 2 players')
    end
    local newtab1 = {beat,plr=plrset}
    local newtab2 = {beat+.001,len-.001,eas,plr=plrset}
    
    local err = false
    
    if #tab % 2 ~= 1 then
        err = true
        throw('measeft: value/mod pair mismatch!')
    else
        for j=4,#tab,2 do
            local amt,mods = tab[j],tab[j+1]
            
            if type(amt) ~= 'table' then
                err = true
                throw('measeft: mod amount is not a table!')
            else
                table.insert(newtab1,amt[1])
                table.insert(newtab1,mods)
                table.insert(newtab2,amt[2])
                table.insert(newtab2,mods)
            end
        end
    end
    
    if not err then
        mset(newtab1)
        mease(newtab2)
    end
    
end

function setcol(t)
    local plr=t.plr or {1,2}
    local newtab={t[1],plr=plr}
    local cols=t.cols or {0,1,2,3}
    if type(cols)=='number' then cols={cols} end
    for i=2,#t,2 do
        local amnt,mod=t[i],t[i+1]
        if type(amnt)~='number' then
            throw("setcol: invalid mod value '"..amnt.."'")
        end
        if type(mod)~='string' then
            throw("setcol: invalid mod '"..mod.."'")
        end
        for _,col in pairs(cols) do
            table.insert(newtab,amnt)
            table.insert(newtab,mod..col)
        end
    end
    set(newtab)
end

function easecol(t)
    local plr=t.plr or {1,2}
    local newtab={t[1],t[2],t[3],plr=plr}
    local cols=t.cols or {0,1,2,3}
    if type(cols)=='number' then cols={cols} end
    for i=4,#t,2 do
        local amnt,mod=t[i],t[i+1]
        if type(amnt)~='number' then
            throw("easecol: invalid mod value '"..amnt.."'")
        end
        if type(mod)~='string' then
            throw("easecol: invalid mod '"..mod.."'")
        end
        for _,col in pairs(cols) do
            table.insert(newtab,amnt)
            table.insert(newtab,mod..col)
        end
    end
    ease(newtab)
end

function addcol(t)
    local plr=t.plr or {1,2}
    local newtab={t[1],t[2],t[3],plr=plr}
    local cols=t.cols or {0,1,2,3}
    if type(cols)=='number' then cols={cols} end
    for i=4,#t,2 do
        local amnt,mod=t[i],t[i+1]
        if type(amnt)~='number' then
            throw("addcol: invalid mod value '"..amnt.."'")
        end
        if type(mod)~='string' then
            throw("addcol: invalid mod '"..mod.."'")
        end
        for _,col in pairs(cols) do
            table.insert(newtab,amnt)
            table.insert(newtab,mod..col)
        end
    end
    add(newtab)
end

function msetcol(t)
    local cols=t.cols or {0,1,2,3}
    if type(cols)=='number' then cols={cols} end
    local plrset=t.plr or {1,2}
    if #plrset>2 then
        throw('msetcol has to be exactly 2 players')
    end
    local newtab={t[1],plr=plrset}
    for i=2,#t,2 do
        local amnt,mod=t[i],t[i+1]
        if type(amnt)~='number' then
            throw("msetcol: invalid mod value '"..amnt.."'")
        end
        if type(mod)~='string' then
            throw("msetcol: invalid mod '"..mod.."'")
        end
        for _,col in pairs(cols) do
            table.insert(newtab,amnt)
            table.insert(newtab,mod..col)
        end
    end
    mset(newtab)
end

function measecol(t)
    local cols=t.cols or {0,1,2,3}
    if type(cols)=='number' then cols={cols} end
    local plrset=t.plr or {1,2}
    if #plrset>2 then
        throw('measecol has to be exactly 2 players')
    end
    local newtab={t[1],t[2],t[3],plr=plrset}
    for i=4,#t,2 do
        local amnt,mod=t[i],t[i+1]
        if type(amnt)~='number' then
            throw("measecol: invalid mod value '"..amnt.."'")
        end
        if type(mod)~='string' then
            throw("measecol: invalid mod '"..mod.."'")
        end
        for _,col in pairs(cols) do
            table.insert(newtab,amnt)
            table.insert(newtab,mod..col)
        end
    end
    mease(newtab)
end

function maddcol(t)
    local cols=t.cols or {0,1,2,3}
    if type(cols)=='number' then cols={cols} end
    local plrset=t.plr or {1,2}
    if #plrset>2 then
        throw('maddcol has to be exactly 2 players')
    end
    local newtab={t[1],t[2],t[3],plr=plrset}
    for i=4,#t,2 do
        local amnt,mod=t[i],t[i+1]
        if type(amnt)~='number' then
            throw("maddcol: invalid mod value '"..amnt.."'")
        end
        if type(mod)~='string' then
            throw("maddcol: invalid mod '"..mod.."'")
        end
        for _,col in pairs(cols) do
            table.insert(newtab,amnt)
            table.insert(newtab,mod..col)
        end
    end
    madd(newtab)
end

function setocol(t)
    local plrset=t.plr or {1,2}
    if #plrset>2 then
        throw('setocol has to be exactly 2 players')
    end
    local newtab={t[1],plr=plrset[1]}
    local newtab2={t[1],plr=plrset[2]}
    local cols=t.cols or {0,1,2,3}
    if type(cols)=='number' then cols={cols} end
    local mcols={[0]=3,2,1,0}
    for i=2,#t,2 do
        local amnt,mod=t[i],t[i+1]
        if type(amnt)~='number' then
            throw("setocol: invalid mod value '"..amnt.."'")
        end
        if type(mod)~='string' then
            throw("setocol: invalid mod '"..mod.."'")
        end
        for _,col in pairs(cols) do
            table.insert(newtab,amnt)
            table.insert(newtab,mod..col)
            table.insert(newtab2,amnt)
            table.insert(newtab2,mod..mcols[col])
        end
    end
    set(newtab)
    set(newtab2)
end

function easeocol(t)
    local plrset=t.plr or {1,2}
    if #plrset>2 then
        throw('easeocol has to be exactly 2 players')
    end
    local newtab={t[1],t[2],t[3],plr=plrset[1]}
    local newtab2={t[1],t[2],t[3],plr=plrset[2]}
    local cols=t.cols or {0,1,2,3}
    if type(cols)=='number' then cols={cols} end
    local mcols={[0]=3,2,1,0}
    for i=4,#t,2 do
        local amnt,mod=t[i],t[i+1]
        if type(amnt)~='number' then
            throw("easeocol: invalid mod value '"..amnt.."'")
        end
        if type(mod)~='string' then
            throw("easeocol: invalid mod '"..mod.."'")
        end
        for _,col in pairs(cols) do
            table.insert(newtab,amnt)
            table.insert(newtab,mod..col)
            table.insert(newtab2,amnt)
            table.insert(newtab2,mod..mcols[col])
        end
    end
    ease(newtab)
    ease(newtab2)
end

function addocol(t)
    local plrset=t.plr or {1,2}
    if #plrset>2 then
        throw('addocol has to be exactly 2 players')
    end
    local newtab={t[1],t[2],t[3],plr=plrset[1]}
    local newtab2={t[1],t[2],t[3],plr=plrset[2]}
    local cols=t.cols or {0,1,2,3}
    if type(cols)=='number' then cols={cols} end
    local mcols={[0]=3,2,1,0}
    for i=4,#t,2 do
        local amnt,mod=t[i],t[i+1]
        if type(amnt)~='number' then
            throw("addocol: invalid mod value '"..amnt.."'")
        end
        if type(mod)~='string' then
            throw("addocol: invalid mod '"..mod.."'")
        end
        for _,col in pairs(cols) do
            table.insert(newtab,amnt)
            table.insert(newtab,mod..col)
            table.insert(newtab2,amnt)
            table.insert(newtab2,mod..mcols[col])
        end
    end
    add(newtab)
    add(newtab2)
end

function msetocol(t)
    local plrset=t.plr or {1,2}
    if #plrset>2 then
        throw('msetocol has to be exactly 2 players')
    end
    local newtab={t[1],plr=plrset[1]}
    local newtab2={t[1],plr=plrset[2]}
    local cols=t.cols or {0,1,2,3}
    if type(cols)=='number' then cols={cols} end
    local mcols={[0]=3,2,1,0}
    for i=2,#t,2 do
        local amnt,mod=t[i],t[i+1]
        if type(amnt)~='number' then
            throw("msetocol: invalid mod value '"..amnt.."'")
        end
        if type(mod)~='string' then
            throw("msetocol: invalid mod '"..mod.."'")
        end
        for _,col in pairs(cols) do
            table.insert(newtab,amnt)
            table.insert(newtab,mod..col)
            table.insert(newtab2,-amnt)
            table.insert(newtab2,mod..mcols[col])
        end
    end
    set(newtab)
    set(newtab2)
end

function measeocol(t)
    local plrset=t.plr or {1,2}
    if #plrset>2 then
        throw('measeocol has to be exactly 2 players')
    end
    local newtab={t[1],t[2],t[3],plr=plrset[1]}
    local newtab2={t[1],t[2],t[3],plr=plrset[2]}
    local cols=t.cols or {0,1,2,3}
    if type(cols)=='number' then cols={cols} end
    local mcols={[0]=3,2,1,0}
    for i=4,#t,2 do
        local amnt,mod=t[i],t[i+1]
        if type(amnt)~='number' then
            throw("measeocol: invalid mod value '"..amnt.."'")
        end
        if type(mod)~='string' then
            throw("measeocol: invalid mod '"..mod.."'")
        end
        for _,col in pairs(cols) do
            table.insert(newtab,amnt)
            table.insert(newtab,mod..col)
            table.insert(newtab2,-amnt)
            table.insert(newtab2,mod..mcols[col])
        end
    end
    ease(newtab)
    ease(newtab2)
end

function maddocol(t)
    local plrset=t.plr or {1,2}
    if #plrset>2 then
        throw('maddocol has to be exactly 2 players')
    end
    local newtab={t[1],t[2],t[3],plr=plrset[1]}
    local newtab2={t[1],t[2],t[3],plr=plrset[2]}
    local cols=t.cols or {0,1,2,3}
    if type(cols)=='number' then cols={cols} end
    local mcols={[0]=3,2,1,0}
    for i=4,#t,2 do
        local amnt,mod=t[i],t[i+1]
        if type(amnt)~='number' then
            throw("maddocol: invalid mod value '"..amnt.."'")
        end
        if type(mod)~='string' then
            throw("maddocol: invalid mod '"..mod.."'")
        end
        for _,col in pairs(cols) do
            table.insert(newtab,amnt)
            table.insert(newtab,mod..col)
            table.insert(newtab2,-amnt)
            table.insert(newtab2,mod..mcols[col])
        end
    end
    add(newtab)
    add(newtab2)
end

--ease stuff
function emix(fn1, fn2, fn3)
	return function(x)
        local fn1e = type(fn1)=='function' and fn1(x) or fn1
        local fn2e = type(fn2)=='function' and fn2(x) or fn2
        local fn3e = type(fn3)=='function' and fn3(x) or fn3
        return (fn1e*fn3e)+(fn2e*(1-fn3e))
    end
end

function eadd(fn1, fn2)
	return function(x)
        local fn1e = type(fn1)=='function' and fn1(x) or fn1
        local fn2e = type(fn2)=='function' and fn2(x) or fn2
        return fn1e+fn2e
    end
end

function esub(fn1, fn2)
	return function(x)
        local fn1e = type(fn1)=='function' and fn1(x) or fn1
        local fn2e = type(fn2)=='function' and fn2(x) or fn2
        return fn1e-fn2e
    end
end

function emult(fn1, fn2)
	return function(x)
        local fn1e = type(fn1)=='function' and fn1(x) or fn1
        local fn2e = type(fn2)=='function' and fn2(x) or fn2
        return fn1e*fn2e
    end
end

function ediv(fn1, fn2)
	return function(x)
        local fn1e = type(fn1)=='function' and fn1(x) or fn1
        local fn2e = type(fn2)=='function' and fn2(x) or fn2
        return fn1e/fn2e
    end
end

function ecutend(fn,cut)
	return function(x)
        if x<=cut then
            return fn(x)
        else
            return 0
        end
    end
end

function ecutbeg(fn,cut)
	return function(x)
        if x>=cut then
            return fn(x)
        else
            return 0
        end
    end
end

function efreeze(fn,perc)
    return function(x)
        if x<=perc then
            return fn(x)
        else
            return fn(perc)
        end
    end
end

node{'drunkoffset',function(p) return 30*p end,'drunkoffset'}
node{'drunkyoffset',function(p) return 30*p end,'drunkyoffset'}
node{'drunkzoffset',function(p) return 30*p end,'drunkzoffset'}
node{'tipsyoffset',function(p) return 30*p end,'tipsyoffset'}

for col=0,3 do
    node{'drunkoffset'..col,function(p) return 30*p end,'drunkoffset'..col}
    node{'drunkyoffset'..col,function(p) return 30*p end,'drunkyoffset'..col}
    node{'drunkzoffset'..col,function(p) return 30*p end,'drunkzoffset'..col}
end

function sm2(tab)
    local beat,len,eas,amt,mods,intime = tab[1],tab[2],tab[3],tab[4],tab[5],tab.intime
    if not intime then intime = .1 end
    if intime <= 0 then intime = .001 end
    add{beat-intime,intime,linear,amt,mods,plr=tab.plr}
    add{beat,len-intime,eas,-amt,mods,plr=tab.plr}
end

node{'bumpyoffset','bumpysize',function(offset,size) return (32+(32*size/100))*pi*offset/100  end,'bumpyoffset'}
node{'bumpyxoffset','bumpyxsize',function(offset,size) return (32+(32*size/100))*pi*offset/100  end,'bumpyxoffset'}
node{'bumpyyoffset','bumpyysize',function(offset,size) return (32+(32*size/100))*pi*offset/100  end,'bumpyyoffset'}
--XeroOl's column specific rotation mods 
for col = 0, 3 do
    definemod {'rotationz'..col,
        function(p)
          if p % 360 == 0 then return 0, 0, 0, 0 end
          if p % 180 == 0 then return 100, 0, 0, 0 end
          local theta = p * math.pi / 180
          return 50 - 50 * math.cos(theta), 900, -212.5, 1000 * math.sin(theta)
        end,
    'reverse'..col, 'zigzagperiod'..col, 'zigzagoffset'..col, 'zigzag'..col}
end
for col = 0, 3 do
    definemod {'rotationx'..col,
        function(p)
          if p % 360 == 0 then return 0, 0, 0, 0 end
          if p % 180 == 0 then return 100, 0, 0, 0 end
          local theta = p * math.pi / 180
          return 50 - 50 * math.cos(theta), 900, -212.5, 1000 * math.sin(theta)
        end,
    'reverse'..col, 'zigzagzperiod'..col, 'zigzagzoffset'..col, 'zigzagz'..col}
end