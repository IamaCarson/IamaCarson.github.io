if not P1 or not P2 then
	backToSongWheel('Two Player Mode Required')
	return
end

-- judgment / combo proxies
for pn = 1, 2 do
	setupJudgeProxy(PJ[pn], P[pn]:GetChild('Judgment'), pn)
	setupJudgeProxy(PC[pn], P[pn]:GetChild('Combo'), pn)
end
-- player proxies
for pn = 1, #PP do
	PP[pn]:SetTarget(P[pn])
	P[pn]:hidden(1)
	P[pn]:x(scx)
end
-- your code goes here here:
GAMESTATE:ForceSmoothLines(0)
aft(my_aft2)
aft(my_aft)
LimitAft(my_aft2)
LimitAft(my_aft)
sprite(my_sprite)
require('parts.intro')
require('parts.part2')
require('parts.part3')
require('parts.part4')
require('parts.part5')
require('parts.part6')
definemod {'fish', function(p)
    my_sprite:GetShader():uniform1f('amount', p);
end}

 set{0,1,'dizzyholds'}