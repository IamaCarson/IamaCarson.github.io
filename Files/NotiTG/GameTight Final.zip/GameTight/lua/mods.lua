if not P1 or not P2 then
	backToSongWheel('Two Player Mode Required')
	return
end

-- judgment / combo proxies
for pn = 1, 2 do
	setupJudgeProxy(PJ[pn], P[pn]:GetChild('Judgment'), pn)
	setupJudgeProxy(PC[pn], P[pn]:GetChild('Combo'), pn)
end
-- player proxies
for pn = 1, #PP do
	PP[pn]:SetTarget(P[pn])
	P[pn]:hidden(1)
end
-- your code goes here here:
	sprite(my_sprite)
	sprite(my_sprite2)
	aft(my_aft)
	aft(my_aft2)
	LimitAft(my_aft)
	LimitAft(my_aft2)
	my_aft:SetFPS(60)
	my_aft2:SetFPS(60)
	card {0, 32, 'aftantic', 0, 'FF6241'}
	card {32, 64, 'Wibble', 1, 'FF6241'}
	card {64, 95, 'Riser 1.wav', 4, 'FF6241'}
	card {95, 127, 'Brute Force', 10, 'FF6241'}
	card {127, 150, 'For Teh Kill', 13, 'FF6241'}
	card {150, 159, 'iphone bbuzzer', 6, 'FF6241'}
	card {159, 224, 'voices', 8, 'FF6241'}
	card {159, 224, 'fad', 8, 'FF6241'}
		slumpo = false
        for pn=1,2 do
            if GAMESTATE:IsPlayerEnabled(pn-1) then
                if GAMESTATE:GetCurrentSteps(pn-1):GetDifficulty() == 4 then
                    slumpo = true
                end
            end
        end
		if slumpo then
			my_sprite:blend('add')
			ease{32,32,linear,360,'rotaz'}
			ease{32-5,5,inQuart,100,'reverse',plr=2}
		end
	--aux mods
		--fade aux for first part
			aux {'fade1'}
		
		--assign aux to node	
			node {'fade1', function(p)
    			return p;
			end}

		--fade aux for second part
			aux {'fade2'}
			
		--assign aux to node	
			node {'fade2', function(p)
    			return p;
			end}

		--aux for aft zoom
			aux {'aftzoom'}
			aux {'2aftzoom'}

		--assign aux to node
			node {'aftzoom', function(p)
    			my_sprite:zoom(p)
			end}
			node {'2aftzoom', function(p)
    			my_sprite2:zoom(p)
			end}

		--glitch lines amount mod
			definemod {'amount', function(p)
        		my_sprite2:GetShader():uniform1f('amount',p)
    		end}

		--glitch lines amount y mod
			definemod {'amounty', function(p)
        		my_sprite2:GetShader():uniform1f('amounty',p)
    		end}

		--aft rotation z mod
			definemod {'aftrotz', function(p)
        		my_sprite:rotationz(p)
    		end}
		
		--aft rotation x mod
			definemod {'aftrotx', function(p)
        		my_sprite:rotationx(p)
    		end}
		
		--aft rotation y mod
			definemod {'aftroty', function(p)
        		my_sprite:rotationy(p)
    		end}
			--aft rotation y mod
			definemod {'aftdiff', function(p)
        		my_sprite:diffusealpha(p)
    		end}
		--aft rotation z mod


	--starting mod assignments
	
		--setup random shit
			set{0,1,'fade1',100,'hidemines'}
			set{0,1,'fade2'}
			set{0,60,'aftrotz'}
			set{0,50,'flip'}
			set{0,700,'movey'}
			set{0,0.97,'aftdiff'}
			set{0,100,'1.8x'}

		
		--ease random shit at begninging
			ease{0,10,outExpo,0,'movey'}
			ease{0,10,linear,1.004,'aftzoom'}

		--center players and hide player 2 for now
		    for pn = 3, 4 do
        P[pn]:SetInputPlayer((pn+1)%2)
        P[pn]:SetAwake(true)
        P[pn]:hidden(1)
        P[pn]:GetChild('Judgment'):hidden(1)
        P[pn]:GetChild('Combo'):hidden(1)
        
    end
			func {0, function()
				for pn=1,2 do
					local plr = P[pn]
					if plr then 
						plr:x(SCREEN_CENTER_X) 
						
					end
				end
			end}

	--Perframe
			
		perframe {0, 31, function(b, reversetions)
				
		--var assignments		
			--spread is devation of strength of mod percentage relative to its assigned column
				local spread = 0.8;
			--how long the transformation is panned out
				local length = 3;
				local length2 = 9.4;
			--how strong anf long it is :lenny:
				local xstrength = math.sin(b/3)*40;
				local ystrength = math.cos(b/3)*20;
				local tstrength = 3;

				
			--col mods
				--my_sprite:rotationz(math.sin(b/3)*30)
				--col1
				
					reversetions[1].movex0 = reversetions[1].movex0 + math.sin(b/length)*(xstrength*10) * reversetions[1].fade1;
					reversetions[1].movey0 = reversetions[1].movey0  + (math.cos(b/length)*((ystrength)*10) + SCREEN_CENTER_Y*0.8) * reversetions[1].fade1;
					reversetions[1].tiny0 = reversetions[1].tiny0  + math.sin(b/length)*((tstrength)*15) * reversetions[1].fade1;
					
				--col2
					reversetions[1].movex1 = reversetions[1].movex1 + math.sin(b/length+spread)*(xstrength*10) * reversetions[1].fade1;
					reversetions[1].movey1 = reversetions[1].movey1  + (math.cos(b/length+spread)*((ystrength)*10) + SCREEN_CENTER_Y*0.8) * reversetions[1].fade1;
					reversetions[1].tiny1 = reversetions[1].tiny1  + math.sin(b/length+spread)*((tstrength)*15) * reversetions[1].fade1;
					
				--col3
					reversetions[1].movex2 = reversetions[1].movex2 + math.sin(b/length+spread*2)*(xstrength*10) * reversetions[1].fade1;
					reversetions[1].movey2 = reversetions[1].movey2  + (math.cos(b/length+spread*2)*((ystrength)*10) + SCREEN_CENTER_Y*0.8) * reversetions[1].fade1;
					reversetions[1].tiny2 = reversetions[1].tiny2  + math.sin(b/length+spread*2)*((tstrength)*15) * reversetions[1].fade1;
					
				--col4
					reversetions[1].movex3 = reversetions[1].movex3 + math.sin(b/length+spread*3)*(xstrength*10) * reversetions[1].fade1;
					reversetions[1].movey3 = reversetions[1].movey3  + (math.cos(b/length+spread*3)*((ystrength)*10) + SCREEN_CENTER_Y*0.8) * reversetions[1].fade1;
					reversetions[1].tiny3 = reversetions[1].tiny3  + math.sin(b/length+spread*3)*((tstrength)*15) * reversetions[1].fade1;
			
				--col1 p2
					reversetions[2].movex0 = reversetions[2].movex0 + math.sin(b/length+length2)*(xstrength*10) * reversetions[1].fade1;
					reversetions[2].movey0 = reversetions[2].movey0  + (math.cos(b/length+length2)*((ystrength)*10) + SCREEN_CENTER_Y*0.8) * reversetions[1].fade1;
					reversetions[2].tiny0 = reversetions[2].tiny0  + math.sin(b/length)*((tstrength)*15) * reversetions[1].fade1;
					
				--col2 p2
					reversetions[2].movex1 = reversetions[2].movex1 + math.sin(b/length+spread+length2)*(xstrength*10) * reversetions[1].fade1;
					reversetions[2].movey1 = reversetions[2].movey1  + (math.cos(b/length+spread+length2)*((ystrength)*10) + SCREEN_CENTER_Y*0.8) * reversetions[1].fade1;
					reversetions[2].tiny1 = reversetions[2].tiny1  + math.sin(b/length+spread)*((tstrength)*15) * reversetions[1].fade1;
					
				--col3 p2
					reversetions[2].movex2 = reversetions[2].movex2 + math.sin(b/length+spread*2+length2)*(xstrength*10) * reversetions[1].fade1;
					reversetions[2].movey2 = reversetions[2].movey2  + (math.cos(b/length+spread*2+length2)*((ystrength)*10) + SCREEN_CENTER_Y*0.8) * reversetions[1].fade1;
					reversetions[2].tiny2 = reversetions[2].tiny2  + math.sin(b/length+spread*2)*((tstrength)*15) * reversetions[1].fade1;
					
				--col4 p2
					reversetions[2].movex3 = reversetions[2].movex3 + math.sin(b/length+spread*3+length2)*(xstrength*10) * reversetions[1].fade1;
					reversetions[2].movey3 = reversetions[2].movey3  + (math.cos(b/length+spread*3+length2)*((ystrength)*10) + SCREEN_CENTER_Y*0.8) * reversetions[1].fade1;
					reversetions[2].tiny3 = reversetions[2].tiny3  + math.sin(b/length+spread*3)*((tstrength)*15) * reversetions[1].fade1;
				
				--rotata
		
					reversetions[2].confusionoffset = (b*50)%628 * reversetions[1].fade1;
					reversetions[1].confusionoffset =   (b *50)%628 * reversetions[1].fade1;

			end}



	--end begining

	definemod{'rotaz',function(a) 
		local conf = -math.rad(a)*100
		local rot = a
		return conf, rot
	end,'confusionzoffset','rotationz'}
		ease{31-6,5,inQuart,0,'fade1'}
		ease{31-6,5,inQuart,0.7,'aftdiff'}
		ease{31-6,5,inQuart,1.11,'aftzoom'}
		ease{31-5,5,linear,0,'flip'}
		ease{26.5,0,linear,0,'aftrotz'}

	
		
	--start lyrics


		--speen
			ease{32,1,linear,1,'fade2'}
			ease{64,21,linear,195,'aftrotz'}
			ease{30,55,linear,0.85,'aftdiff'}
			ease{62,2,linear,0,'fade2'}
			
	
			set{32, 0.001, 'drunkperiod'}
			perframe {32, 64-32, function(b, reversetions)
				my_sprite2:rotationz( math.sin(b) * 10 * reversetions[1].fade2 )
				my_sprite2:rotationx( math.cos(b) * 30 * reversetions[1].fade2 )
				my_sprite2:rotationy( math.sin(b) * 30 * reversetions[1].fade2 )
				reversetions[1].noteskewx0 =  math.sin(b)*50 * reversetions[1].fade2;
				reversetions[2].noteskewx0 =  math.sin(b)*50 * reversetions[1].fade2;
				reversetions[1].noteskewx1 =  math.sin(b+1)*50 * reversetions[1].fade2;
				reversetions[2].noteskewx1 =  math.sin(b+1)*50 * reversetions[1].fade2;
				reversetions[1].noteskewx2 =  math.sin(b+2)*50 * reversetions[1].fade2;
				reversetions[2].noteskewx2 =  math.sin(b+2)*50 * reversetions[1].fade2;
				reversetions[1].noteskewx3 =  math.sin(b+3)*50 * reversetions[1].fade2;
				reversetions[2].noteskewx3 =  math.sin(b+3)*50 * reversetions[1].fade2;
				reversetions[2].drunk =  math.sin(b)*30 * reversetions[1].fade2;
				reversetions[1].drunk =  math.sin(b)*30 * reversetions[1].fade2;
				reversetions[1].tipsy =  math.sin(b)*70 * reversetions[1].fade2;
				reversetions[2].tipsy =  math.sin(b)*70 * reversetions[1].fade2;
				reversetions[1].aftrotz =  math.sin(b)*7 * reversetions[1].fade2;
				if slumpo then
				reversetions[1].reverse =  math.sin(b)*-50+50 * reversetions[1].fade2;
				reversetions[2].reverse =  math.sin(-b)*-50+50 * reversetions[1].fade2;
				reversetions[1].attenuate =  math.sin(b)*-400+400 * reversetions[1].fade2;

				end
			end}

			


			


		--hate
		local ease1 = inOutQuad

		
		ease{32,2,pop,150,'zoom'}
		ease{32,4,pop,1.3,'aftzoom'}


		



		--aaaaaa

		




		--c2l
	

			local cBoom = {{32, 1}, {36, 1}, {40, 1}, {44, 1}, {48, 1}, {52, 1}, {56, 1}, {60, 1}}

			for i = 1, #cBoom do
				set{cBoom[i][1],1.0,'2aftzoom'}
				ease{cBoom[i][1],4,pop,1.3,'aftzoom'}
				ease{cBoom[i][1],2,outQuad,1.5,'2aftzoom'}
				ease{cBoom[i][1]+2,2,inQuad,1.0,'2aftzoom'}
			end

			local cTss = {{37, 2}, {39, 2}, {41, 2}, {43, 2}, {45, 2}, {47, 2}, {47.5, 2}, {48, 2}, {53, 2}, {55, 2}, {55.5, 2}, {56, 2}, {57, 2}, {59, 2}, {60, 2}, {60.5, 2}, {61, 2}, {61.5, 2}, {62, 2}, {62.5, 2}, {63, 2}, {63.5, 2}}
			
			for i = 1, #cTss do
				ease{cTss[i][1],1,pop,10,'bumpyx'}
			end


--dundun
	--3wre
	for i=64, 79 ,2 do
		set{i,0,'zoom',plr=2}
		ease{i,1,outQuart,100,'zoom',plr=2}
		ease{i,1,outQuart,250,'zoom',plr=1}
		ease{i,1,pop,1.1,'aftzoom'}
		ease{i+1,1,pop,1.1,'aftzoom'}

		set{i+1,0,'zoom',plr=1}
		ease{i+1,1,outQuart,100,'zoom',plr=1}
		ease{i+1,1,outQuart,250,'zoom',plr=2}
		
	end
	for i=80, 88 ,1 do
		set{i,0,'zoom',plr=2}
		ease{i,1,outQuart,100,'zoom',plr=2}
		ease{i,1,outQuart,250,'zoom',plr=1}
		ease{i,0.5,pop,1.2,'aftzoom'}
		ease{i+0.5,0.5,pop,1.2,'aftzoom'}
		set{i+0.5,0,'zoom',plr=1}
		ease{i+0.5,1,outQuart,100,'zoom',plr=1}
		ease{i+0.5,1,outQuart,250,'zoom',plr=2}
	end
					for i = 64, 79, 2 do
					if slumpo then
						ease{i+1,1,outQuart,100,'reverse',plr=1}
						ease{i,1,outQuart,100,'reverse',plr=1}
						ease{i+1,1,outQuart,0,'reverse',plr=2}
						ease{i,1,outQuart,0,'reverse',plr=2}
						ease{i,1,bounce,-30,'flip'}
						ease{i+1,1,bounce,-30,'flip'}
					end
	ease{i,1,outQuart,100,'invert',plr=1}
	
	ease{i,1,outQuart,0,'invert',plr=2}
	ease{i+1,1,outQuart,0,'invert',plr=1}
	
	ease{i+1,1,outQuart,100,'flip',plr=2}
	ease{i+2,1,outQuart,100,'flip',plr=1}
	ease{i+2,1,outQuart,0,'flip',plr=2}
				
	end
	for i = 80, 85.5, 1.5  do
		if slumpo then
			ease{i+1,1,outQuart,100,'reverse',plr=1}
			ease{i,1,outQuart,100,'reverse',plr=1}
			ease{i+1,1,outQuart,0,'reverse',plr=2}
			ease{i,1,outQuart,0,'reverse',plr=2}
			ease{i,1,bounce,-30,'flip'}
			ease{i+1,1,bounce,-30,'flip'}
		end
	ease{i,0.5,outQuart,100,'invert',plr=1}
	ease{i,0.5,outQuart,0,'invert',plr=2}
	ease{i+0.5,0.5,outQuart,0,'invert',plr=1}
	ease{i+0.5,0.5,outQuart,100,'flip',plr=2}
	ease{i+1,0.5,outQuart,100,'flip',plr=1}
	ease{i+1,0.5,outQuart,0,'flip',plr=2}
	ease{i+1.5,0.5,outQuart,0,'flip',plr=1}
	ease{i+1.5,0.5,outQuart,100,'invert',plr=2}
	end
	ease{87,0.5,linear,0,'invert',plr=2}
	for i=88, 91.5 , 0.5 do 
		ease{i,0.25,pop,1.1,'aftzoom'}
		ease{i+0.25,0.25,pop,1.1,'aftzoom'}
		set{i,0,'zoom',plr=2}
		ease{i,0.25,outQuart,100,'zoom',plr=2}
		ease{i,0.25,outQuart,250,'zoom',plr=1}
		set{i+0.25,0.25,'zoom',plr=1}
		ease{i+0.25,0.25,outQuart,100,'zoom',plr=1}
		ease{i+0.25,0.25,outQuart,250,'zoom',plr=2}
		set{i,math.random()*100 ,'flip',plr=1}
		set{i,math.random()*101 ,'flip',plr=2}
		set{i,math.random()*100 ,'invert',plr=1}
		set{i,math.random()*101 ,'invert',plr=2}
	end
	ease{92,0.25,linear,0,'flip',plr=1}
	ease{92,0.25,linear,0,'flip',plr=2}
	ease{92,0.25,linear,0,'invert',plr=1}
	ease{92,0.25,linear,0,'invert',plr=2}
	local chart = P[1]:GetNoteData()
    for i,v in ipairs(chart) do
        if v[3] == 'M' then
              set{v[1]-.3,100,'hidenoteflash'..v[2]}
              set{v[1]+.3,0,'hidenoteflash'..v[2]}
        end
    end
--drop
	--funny aft
		ease{88,3,linear,60,'aftrotz'}
	--c2l
		local ppboner={95,95,96,97,98,99,100,101,102,102.5,103,104,105,106,107,108,109,110,110.75,111.5,112,113,114,115,116,117,118,120,121,122,123,124,124.5,125.25,126,127,127,128,129,130,131,132,133,134,134.5,135,136,137,138,139,140,141,142,142.5,142.75,143,144,145,146,147,148,149}
	local quandale = 1
		for i = 1, #ppboner do
			if slumpo then
				ease{ppboner[i],1,outQuad,50+50*quandale,'reverse'}
			end
			ease{ppboner[i],0.95,pop,-170,'invert'}
			ease{ppboner[i],0.95,pop,170,'flip'}
			if slumpo then
			ease{ppboner[i],2,bounce,130,'zoom',20*quandale,'rotationz'}
			end
			ease{ppboner[i],1,pop,-500,'tiny'}
			ease{ppboner[i],0.5,outExpo,1.6,'aftzoom'}
			ease{ppboner[i]+0.5,0.5,inExpo,1,'aftzoom'}
			ease{ppboner[i],0.5,pop,0.15,'amount'}
			ease{ppboner[i],0.8,pop,0.001,'amounty'}
			ease{ppboner[i],2,pop,math.random()*40-20,'confusionoffset0'}
			ease{ppboner[i],2,pop,math.random()*40-20,'confusionoffset1'}
			ease{ppboner[i],2,pop,math.random()*40-20,'confusionoffset2'}
			ease{ppboner[i],2,pop,math.random()*40-20,'confusionoffset3'}
			quandale = quandale * -1
		end
	--rotate		
		for i = 95, 127,2 do

			ease{i,0.8,pop,-40,'rotationz'}
			ease{i+1,0.8,pop,40,'rotationz'}
		end

		--funky
		for i = 127, 142,2 do

			ease{i,0.6,bounce,-18,'rotationz'}
		ease{i+1,0.6,bounce,18,'rotationz'}
		end
	set{160,100,'zoom'}
	set{160,0.75,'aftdiff'}



if slumpo then
	for i=160, 174 ,2 do
		ease{i,1,bounce,-30,'rotationz'}
		ease{i,1,bounce,100,'flip',plr=1}
		ease{i,1,outQuint,0,'flip',plr=2}
		ease{i+1,1,outQuint,0,'flip',plr=1}
		ease{i+1,1,outQuint,100,'flip',plr=2}
		ease{i+1,1,outQuint,30,'rotationz'}
		set{i,0,'zoom',plr=2}
		ease{i,1,outSine,100,'zoom',plr=2}
		ease{i,1,outSine,250,'zoom',plr=1}
		ease{i,1,pop,1.3,'aftzoom'}
		ease{i+1,1,pop,1.3,'aftzoom'}
		set{i+1,0,'zoom',plr=1}
		ease{i+1,1,outQuart,100,'zoom',plr=1}
		ease{i+1,1,outQuart,250,'zoom',plr=2}
	end
	for i=160, 223 ,1 do
		ease{i,0.7,pop,0.04,'amount'}
		ease{i,1,pop,0.004,'amounty'}
		ease{i,0.3,pop,-150,'invert'}
		ease{i,0.5,pop,100,'flip'}
		ease{i,2,pop,math.random()*120-60,'confusionoffset0'}
		ease{i,2,pop,math.random()*120-60,'confusionoffset1'}
		ease{i,2,pop,math.random()*120-60,'confusionoffset2'}
		ease{i,2,pop,math.random()*120-60,'confusionoffset3'}
		ease{i,0.5,pop,-800,'tiny'}
	end
else 
	for i=160, 174 ,2 do
		ease{i,1,bounce,-30,'rotationz'}
		ease{i+1,1,bounce,30,'rotationz'}
		set{i,0,'zoom',plr=2}
		ease{i,1,outSine,100,'zoom',plr=2}
		ease{i,1,outSine,250,'zoom',plr=1}
		ease{i,1,pop,1.1,'aftzoom'}
		ease{i+1,1,pop,1.1,'aftzoom'}
		set{i+1,0,'zoom',plr=1}
		ease{i+1,1,outQuart,100,'zoom',plr=1}
		ease{i+1,1,outQuart,250,'zoom',plr=2}
	end
	quandale = 1
	for i=160, 223 ,1 do
		ease{i,0.7,pop,0.01,'amount'}
		ease{i,1,pop,0.001,'amounty'}
		ease{i,0.3,pop,-150,'invert'}
		ease{i,0.5,pop,100,'flip'}
		if slumpo then
		ease{i,1,bounce,20*quandale,'rotationz'}
		ease{i,1,pop,-2000,'tinyz'}
		end
		ease{i,2,pop,math.random()*120-60,'confusionoffset0'}
		ease{i,2,pop,math.random()*120-60,'confusionoffset1'}
		ease{i,2,pop,math.random()*120-60,'confusionoffset2'}
		ease{i,2,pop,math.random()*120-60,'confusionoffset3'}
		ease{i,0.5,pop,-300,'tiny'}
		quandale = quandale * -1
	end
end
	for i=176, 192 ,2 do
		ease{i,1,bounce,-20,'rotationz'}
		ease{i+1,1,bounce,20,'rotationz'}
		set{i,250,'zoom',plr=2}
		ease{i,1,outQuart,100,'zoom',plr=2}
		ease{i,1,outQuart,0,'zoom',plr=1}
		ease{i,1,pop,1.1,'aftzoom'}
		ease{i+1,1,pop,1.1,'aftzoom'}
		set{i+1,250,'zoom',plr=1}
		ease{i+1,1,outQuart,0,'zoom',plr=2}
		ease{i+1,1,outQuart,100,'zoom',plr=1}
	end

	for i=192, 206 ,2 do
		ease{i,1,bounce,-25,'rotationz'}
		ease{i+1,1,bounce,25,'rotationz'}
		set{i,0,'zoom',plr=2}
		ease{i,1,outSine,100,'zoom',plr=2}
		ease{i,1,outSine,250,'zoom',plr=1}
		ease{i,1,pop,1.1,'aftzoom'}
		ease{i+1,1,pop,1.1,'aftzoom'}
		set{i+1,0,'zoom',plr=1}
		ease{i+1,1,outQuart,100,'zoom',plr=1}
		ease{i+1,1,outQuart,250,'zoom',plr=2}
	end
	for i=208, 223 ,2 do
		ease{i,1,bounce,-20,'rotationz'}
		ease{i+1,1,bounce,20,'rotationz'}
		set{i,250,'zoom',plr=2}
		ease{i,1,outQuart,100,'zoom',plr=2}
		ease{i,1,outQuart,0,'zoom',plr=1}
		ease{i,1,pop,1.1,'aftzoom'}
		ease{i+1,1,pop,1.1,'aftzoom'}
		set{i+1,250,'zoom',plr=1}
		ease{i+1,1,outQuart,0,'zoom',plr=2}
		ease{i+1,1,outQuart,100,'zoom',plr=1}
	end
local notedataaaa={150,150.5,151,152,152.5,153,153.5,154,154.5,155,156,156.5,157.5,158,158.5,158.75,159}
quandale = 1
			for i = 1, #notedataaaa do
			
			if slumpo then
				add{notedataaaa[i],0.5,bounce,-10,'flip',10*quandale,'rotationz'}
				
			end
			quandale = quandale * -1
			ease{notedataaaa[i],0.5,bounce,10,'flip'}
			ease{notedataaaa[i],0.5,bounce,-40,'invert'}
			ease{notedataaaa[i],1,bounce,140,'zoom'}
			ease{notedataaaa[i],0.5,pop,-10,'tiny'}
			ease{notedataaaa[i],0.25,outExpo,1.6,'aftzoom'}
			ease{notedataaaa[i]+0.25,0.25,inExpo,1,'aftzoom'}
			ease{notedataaaa[i],0.5,pop,0.01,'amount'}
			ease{notedataaaa[i],0.8,pop,0.001,'amounty'}
			ease{notedataaaa[i],0.5,pop,math.random()*100-50,'confusionoffset0'}
			ease{notedataaaa[i],0.5,pop,math.random()*100-50,'confusionoffset1'}
			ease{notedataaaa[i],0.5,pop,math.random()*100-50,'confusionoffset2'}
			ease{notedataaaa[i],0.5,pop,math.random()*100-50,'confusionoffset3'}
		end
	ease{224,1,linear,0.70,'aftdiff'}
	for i=224, 254 ,8 do
		set{i,0,'zoom',plr=2}
		set{i,0,'invert',plr=2}
		ease{i,4,linear,100,'zoom',plr=2}
		ease{i,2,linear,100,'invert',plr=2}
		ease{i,4,linear,250,'zoom',plr=1}
		set{i+4,0,'zoom',plr=1}
		set{i+4,0,'flip',plr=1}
		ease{i+4,4,linear,100,'zoom',plr=1}
		ease{i+4,2,linear,100,'flip',plr=1}
		ease{i+4,4,linear,250,'zoom',plr=2}
	end

	ease{256,1,linear,0.0,'flip',plr=1}
	ease{256,1,linear,0.0,'invert',plr=2}
	ease{256,2,linear,0.0,'aftdiff'}
	